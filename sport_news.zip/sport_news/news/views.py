from django.shortcuts import render, redirect, get_object_or_404
from .models import News, Category
from .forms import NewsForm

def index(request):
    return render(request, 'news/index.html')

def news_list(request):
    news = News.objects.all()  # Barcha yangiliklarni olish
    return render(request, 'news/news_list.html', {'news_list': news})

def news_detail(request, id):
    news = get_object_or_404(News, id=id)  # Yangilikni ID orqali olish
    return render(request, 'news/news_detail.html', {'news': news})

def add_news(request):  # Funksiya nomini o'zgartirdik
    if request.method == 'POST':
        form = NewsForm(request.POST)  # Forma orqali ma'lumotlar
        if form.is_valid():
            form.save()  # Yangilikni saqlash
            return redirect('news_list')  # Yangiliklar ro'yxatiga qaytish
    else:
        form = NewsForm()  # Yangi forma
    return render(request, 'news/create_news.html', {'form': form})
